/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package juice;

/**
 *
 * @author termi303
 */
public class AppleJuice extends Juice {
    @Override
    public void drink() {
        System.out.println("Drink apple juice");
    }
}
