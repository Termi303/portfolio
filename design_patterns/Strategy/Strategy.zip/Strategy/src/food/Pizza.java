/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package food;

/**
 *
 * @author termi303
 */
public class Pizza extends Food {
    @Override
    public void eat() {
        System.out.println("eat pizza");
    }
}
